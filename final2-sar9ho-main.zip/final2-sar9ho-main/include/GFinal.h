/*
 *  Copyright 2020 Mike Reed
 */

#ifndef GFinal_DEFINED
#define GFinal_DEFINED

#include "GCanvas.h"
#include "GPath.h"
#include "GPathBuilder.h"
#include "GShader.h"
#include <array>

/**
 * Override and implement these methods. You must implement GCreateFinal() to return your subclass.
 *
 * Each method has a default (do nothing) impl, so you only need to override the ones you intended to implement.
 */
class GFinal {
public:
    virtual ~GFinal() {}

    /**
     * The vornoi shader is defined by an array of points, each with an associated color.
     * The color any any (x,y) is the color of the closest point from the array.
     */
    virtual std::shared_ptr<GShader> createVoronoiShader(const GPoint points[],
                                                         const GColor colors[],
                                                         int count) {
        return nullptr;
    }

    /**
     *  Return a sweep-gradient shader, centered at 'center', starting wiht color[0] at  startRadians
     *  and ending with colors[count-1] at startRadians+2pi. The colors are distributed evenly around the sweep.
     */
    virtual std::shared_ptr<GShader> createSweepGradient(GPoint center, float startRadians,
                                                         const GColor colors[], int count) {
        return nullptr;
    }

    /**
     *  Construct a path that, when drawn, will look like a stroke of the specified polygon.
     *  - count is the number of points in the polygon (it will be >= 2)
     *  - width is the thickness of the stroke that should be centered on the polygon edges
     *  - isClosed specifies if the polygon should appear closed (true) or open (false).
     *
     *  Any caps or joins needed should be round (circular).
     */
    virtual std::shared_ptr<GPath> strokePolygon(const GPoint[], int count, float width, bool isClosed) {
        return nullptr;
    }

    /*
     *  Draw the corresponding mesh constructed from a quad with each side defined by a
     *  quadratic bezier, evaluating them to produce "level" interior lines (same convention
     *  as drawQuad().
     *
     *  pts[0]    pts[1]    pts[2]
     *  pts[7]              pts[3]
     *  pts[6]    pts[5]    pts[4]
     *
     *  Evaluate values within the mesh using the Coons Patch formulation:
     *
     *  value(u,v) = TB(u,v) + LR(u,v) - Corners(u,v)
     *
     *     Top is quadratic bezier: pts[0], pts[1], pts[2]
     *  Bottom is quadratic bezier: pts[6], pts[5], pts[4]
     *    Left is quadratic bezier: pts[0], pts[7], pts[6]
     *   Right is quadratic bezier: pts[2], pts[3], pts[4]
     *
     *  Where
     *      TB is computed by first evaluating the Top and Bottom curves at (u), and then
     *      linearly interpolating those points by (v)
     *
     *      LR is computed by first evaluating the Left and Right curves at (v), and then
     *      linearly interpolating those points by (u)
     *
     *      Corners is computed by our standard "drawQuad" evaluation using the 4 corners 0,2,4,6
     */
    virtual void drawQuadraticCoons(GCanvas*, const GPoint pts[8], const GPoint tex[4],
                                    int level, const GPaint&) {}

    /*
     * Given an array of points, construct a "smooth" path contour, and add it to the builder.
     *
     * The technique is to turn every point pts[i] into the "middle" point of a
     * quadratic bezier. For example, if a quadratic bezier is defined by points A, B, C
     *     (1 - t)^2 A + 2t(1 - t) B + t^2 C
     * then each point pts[i] is a "B", and A and C are computed as the mid-point between
     * the neighboring points:
     *      A = mid_point(pts[i-1], pts[i])
     *      C = mid_point(pits[i], pts[i+1])
     * ... remembering to "wrap around" the array, such the index might have to wrap to stay
     *     in [0..count-1] (since we're making a closed loop out of the array of points).
     *
     * Note: if count < 3, this should do nothing.
     */
    virtual void addSmoothContour(GPathBuilder*, const GPoint pts[], int count) {}
};

/**
 *  Implement this to return ain instance of your subclass of GFinal.
 */
std::unique_ptr<GFinal> GCreateFinal();

#endif
