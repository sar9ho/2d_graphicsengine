/**
 *  Copyright 2023 Mike Reed
 */

#include <stdio.h>

extern int main_image(int argc, const char* argv[]);

int main(int argc, const char* argv[]) {
    return main_image(argc, argv);
}

