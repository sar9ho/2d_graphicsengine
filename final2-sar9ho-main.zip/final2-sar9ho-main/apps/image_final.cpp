/**
 *  Copyright 2018 Mike Reed
 */

#include "image.h"

#include "../include/GFinal.h"
#include "../include/GCanvas.h"
#include "../include/GBitmap.h"
#include "../include/GColor.h"
#include "../include/GMatrix.h"
#include "../include/GPathBuilder.h"
#include "../include/GPoint.h"
#include "../include/GRandom.h"
#include "../include/GRect.h"
#include <string>

struct Rec {
    GPoint        center;
    float         startRadians;
    float         radius;
    const GColor* colors;
    int           count;

    void draw(GCanvas* canvas, GFinal* f) const {
        if (auto sh = f->createSweepGradient(center, startRadians, colors, count)) {
            auto path = GPathBuilder::Build([&](GPathBuilder& bu) {
                bu.addCircle(center, radius);
            });
            canvas->drawPath(*path, GPaint(sh));
        }
    }
};

static void final_sweep(GCanvas* canvas) {
    auto fin = GCreateFinal();

    const GColor c0[] = {
            {1, 0, 0, 1},
            {1, 1, 0, 1},
            {0, 1, 0, 1},
            {0, 1, 1, 1},
            {0, 0, 1, 1},
            {1, 0, 1, 1},
            {1, 0, 0, 1},
    };

    const GColor c1[] = {
        {0, 0, 0, 1}, {1, 1, 1, 1}, {0, 0, 0, 1},
    };

    const Rec recs[] = {
        { {128, 256}, gFloatPI/2, 250, c1, GARRAY_COUNT(c1)},
        { {128, 256}, 0, 200, c0, GARRAY_COUNT(c0)},
        { {128, 256}, -gFloatPI/2, 150, c1, GARRAY_COUNT(c1)},
        { {128, 256}, gFloatPI, 100, c0, GARRAY_COUNT(c0)},
        { {128, 256}, 0, 50, c1, 2},
    };
    canvas->translate(128, 0);
    for (const auto& r : recs) {
        r.draw(canvas, fin.get());
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////

static void final_coons(GCanvas* canvas) {
    GBitmap bm;
    bm.readFromFile("apps/spock.png");
    assert(bm.width());
    assert(bm.height());

    GPoint pts[] = {
        {0, 0}, {0.25f, 0.5}, {1, 0},
                              {1.25, 0.5f},
                              {0.75, 1},
                {0.5f, 0.75},
        {0, 1.125},
        {0.25, 0.5f},
    };
    auto mx = GMatrix::Translate(30, 30) * GMatrix::Scale(400, 400);
    mx.mapPoints(pts, pts, 8);

    GPoint tex[] = {
        {0, 0}, {1, 0}, {1, 1}, {0, 1},
    };
    GMatrix::Scale(bm.width(), bm.height()).mapPoints(tex, tex, 4);

    GPaint paint(GCreateBitmapShader(bm, GMatrix()));

    const int N = 8;
    GCreateFinal()->drawQuadraticCoons(canvas, pts, tex, N, paint);
}

//////////////////////////////////////////

static void make_star(std::vector<GPoint>& pts, int count, float anglePhase) {
    assert(count & 1);
    float da = 2 * gFloatPI * (count >> 1) / count;
    float angle = anglePhase;
    for (int i = 0; i < count; ++i) {
        pts.push_back({ cosf(angle), sinf(angle) });
        angle += da;
    }
}

std::vector<GPoint> make_wiggle(float scalex, float scaley) {
    float limit = 4 * gFloatPI;
    float da = limit / 40;
    std::vector<GPoint> pts;
    for (float a = 0; a <= limit; a += da) {
        pts.push_back({std::sin(a) * scalex, a * scaley});
    }
    return pts;
}

static void final_stroke(GCanvas* canvas) {
    auto f = GCreateFinal();

    GPaint paint;
    float w = 20;

    paint.setColor({1, 0, 0, 1});
    float dx = 120, dy = 90;
    const GPoint pts[] = {
        {dx, dy}, {512-dx, 512-dy}, {512-dx,dy}, {dx,512-dy},
    };
    canvas->drawPath(f->strokePolygon(pts, 4, 70, true), paint);
    paint.setBlendMode(GBlendMode::kClear);
    canvas->drawPath(f->strokePolygon(pts, 4, 25, true), paint);
    paint.setBlendMode(GBlendMode::kSrcOver);

    std::vector<GPoint> poly;
    make_star(poly, 7, gFloatPI/14);
    w = 15;
    canvas->save();
    canvas->translate(256, 310);
    canvas->scale(190,  190);
    paint.setColor({0,0,1,1});
    canvas->drawPath(f->strokePolygon(poly.data(), poly.size(), w/256, true), paint);
    canvas->restore();

    poly = make_wiggle(25, 30);
    canvas->save();
    canvas->translate(40, 75);
    paint.setColor({0,1,0,1});
    auto path = f->strokePolygon(poly.data(), poly.size(), 15, false);
    canvas->drawPath(path, paint);
    paint.setColor({1,0,1,1});
    canvas->translate(432, 0);
    canvas->drawPath(path, paint);
    canvas->restore();
}

static void final_voronoi(GCanvas* canvas) {
    auto f = GCreateFinal();

    canvas->scale(4, 4);
    GRandom rand;
    const int n = 20;
    GColor colors[n];
    GPoint points[n];
    for (int i = 0; i < n; ++i) {
        float x = rand.nextF() * 128;
        float y = rand.nextF() * 128;
        points[i] = {x, y};
        float r = rand.nextF();
        float g = rand.nextF();
        float b = rand.nextF();
        colors[i] = {r, g, b, 1};
    }

    auto path = GPathBuilder::Build([](GPathBuilder& bu) {
        bu.addCircle({64, 64}, 64);
    });

    auto sh = f->createVoronoiShader(points, colors, n);
    if (!sh) {
        return;
    }
    GPaint paint(sh);

    for (int i = 0; i < n; ++i) {
        points[i] = {-1, -1};
        colors[i] = {0, 0, 0, 0};
    }

    canvas->drawPath(path, paint);
}

static std::vector<GPoint> make_circle(GPoint center, float radius, float phase, int sides) {
    std::vector<GPoint> pts;
    float dangle = 2 * gFloatPI / sides;
    if (radius < 0) {
        dangle = -dangle;
        radius = -radius;
    }

    float angle = phase;
    for (int i = 0; i < sides; ++i) {
        auto x = std::cos(angle) * radius;
        auto y = std::sin(angle) * radius;
        pts.push_back({center.x + x, center.y + y});
        angle += dangle;
    }
    return pts;
}

static void final_smoothpath(GCanvas* canvas) {
    auto fobj = GCreateFinal();
    auto f = fobj.get();
    auto draw = [canvas](std::shared_ptr<GPath> path, const GColor& c) {
        if (path) {
            GPaint paint(c);
            canvas->drawPath(*path, paint);
        }
    };

    auto add = [f](GPathBuilder* bu, const std::vector<GPoint>& pts) {
        f->addSmoothContour(bu, pts.data(), (int)pts.size());
    };

    GRandom rand;

    GPathBuilder bu;
    auto center = GPoint{128, 128};
    add(&bu, make_circle(center, 140, 0, 3));
    add(&bu, make_circle(center, -100, gFloatPI/3, 3));
    draw(bu.detach(), {0, 0, 1, 1});

    {
        const GPoint pts[] = {
            {0, 0}, {240, 0}, {240, 240},
        };
        f->addSmoothContour(&bu, pts, GARRAY_COUNT(pts));
        bu.transform(GMatrix::Translate(236, 35));
        draw(bu.detach(), {1, 0, 0, 1});
    }

    {
        const float x = 70, y = 150;
        for (int i = 0; i < 3; ++i) {
            std::vector<GPoint> pts = {
                {-x, -y}, {x,  -y}, {-x, y}, {x,  y},
            };
            GMatrix::Rotate(i * 2 * gFloatPI / 3).mapPoints(pts.data(), pts.size());
            add(&bu, pts);
        }
        bu.transform(GMatrix::Translate(256, 350));
        draw(bu.detach(), {0, 0.75, 0, 1});

    }
}